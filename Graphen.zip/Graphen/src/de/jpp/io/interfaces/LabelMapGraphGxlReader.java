package de.jpp.io.interfaces;

import de.jpp.model.LabelMapGraph;
import de.jpp.model.interfaces.Edge;
import org.jdom2.*;
import org.jdom2.input.SAXBuilder;

import java.io.StringReader;
import java.util.*;

public class LabelMapGraphGxlReader implements GraphReader<String, Map<String, String>, LabelMapGraph, String> {

    @Override
    public LabelMapGraph read(String input) throws ParseException {
        if (input == null || input.trim().isEmpty()) {
            throw new ParseException();
        }
        try {
            SAXBuilder saxBuilder = new SAXBuilder();
            Document document = saxBuilder.build(new StringReader(input));

            Element rootElement = document.getRootElement();
            if (!"gxl".equals(rootElement.getName())) {
                throw new ParseException();
            }

            Element graphElement = rootElement.getChild("graph");
            if (graphElement == null) {
                throw new ParseException();
            }

            LabelMapGraph graph = new LabelMapGraph();
            Map<String, String> nodeMap = new HashMap<>();

            List<Element> nodeElements = graphElement.getChildren("node");
            for (Element nodeElement : nodeElements) {
                parseNode(nodeElement, graph, nodeMap);
            }

            List<Element> edgeElements = graphElement.getChildren("edge");
            for (Element edgeElement : edgeElements) {
                parseEdge(edgeElement, graph, nodeMap);
            }
            return graph;

        } catch (JDOMException | java.io.IOException e) {
            throw new ParseException("Error beim Parsen der GXL: " + e.getMessage());
        } catch (Exception e) {
            if (e instanceof ParseException) {
                throw e;
            }
            throw new ParseException("Error beim Parsen der GXL: " + e.getMessage());
        }
    }

    private void parseNode(Element nodeElement, LabelMapGraph graph, Map<String, String> nodeMap) throws ParseException {
        String nodeId = readNodeId(nodeElement);
        if (nodeId == null || nodeId.isEmpty()) {
            throw new ParseException();
        }

               Map<String, String> attributes = parseAllAttributes(nodeElement);


        String nodeLabel = attributes.getOrDefault("description", nodeId);

        nodeMap.put(nodeId, nodeLabel);
        graph.addNode(nodeLabel);
    }

    private void parseEdge(Element edgeElement, LabelMapGraph graph, Map<String, String> nodeMap) throws ParseException {
        String fromId = edgeElement.getAttributeValue("from");
        String toId = edgeElement.getAttributeValue("to");

        if (fromId == null || fromId.isEmpty()) {
            throw new ParseException();
        }
        if (toId == null || toId.isEmpty()) {
            throw new ParseException();
        }

        String fromNode = nodeMap.get(fromId);
        String toNode = nodeMap.get(toId);

        if (fromNode == null) {
            throw new ParseException("Kante referenziert unknown node: " + fromId);
        }
        if (toNode == null) {
            throw new ParseException("Kante referenziert unknown node: " + toId);
        }

        Map<String, String> edgeAttributes = parseAllAttributes(edgeElement);

        graph.addEdge(fromNode, toNode, Optional.of(edgeAttributes));
    }

    private String readNodeId(Element nodeElement) {
        return nodeElement.getAttributeValue("id");
    }

    private Map<String, String> parseAllAttributes(Element element) throws ParseException {
        Map<String, String> attributes = new HashMap<>();

        List<Element> attrElements = element.getChildren("attr");
        for (Element attrElement : attrElements) {
            String attrName = attrElement.getAttributeValue("name");
            if (attrName == null) {
                continue;
            }
            String value = getAttrValueAsString(attrElement);
            if (value != null) {
                attributes.put(attrName, value);
            }
        }

        return attributes;

    }

    private String getAttrValueAsString(Element attrElement) throws ParseException {
        List<Element> children = attrElement.getChildren();
        if (children.isEmpty()) {
            throw new ParseException();
        }

        Element valueElement = children.get(0);
        return valueElement.getTextTrim();
    }
}
