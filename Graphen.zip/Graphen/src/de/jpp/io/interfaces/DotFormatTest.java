package de.jpp.io.interfaces;

import de.jpp.factory.IOFactory;
import de.jpp.io.interfaces.GraphReader;
import de.jpp.io.interfaces.GraphWriter;
import de.jpp.io.interfaces.ParseException;
import de.jpp.model.TwoDimGraph;
import de.jpp.model.XYNode;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DotFormatTest {

    private static final String TEST_FILES_PATH = "C:\\Users\\Sergiu-DanielSica\\Downloads\\Graphen_IO_Test_Files (1)\\TestFiles\\dot";

    public static void main(String[] args) {
        testDotFiles();
    }

    public static void testDotFiles() {
        System.out.println("=== Testing DOT Format Parser ===");

        IOFactory factory = new IOFactory();
        GraphReader<XYNode, Double, TwoDimGraph, String> reader = factory.getTwoDimDotReader();
        GraphWriter<XYNode, Double, TwoDimGraph, String> writer = factory.getTwoDimDotWriter();

        // Test valid files
        testValidDotFiles(reader, writer);

        // Test invalid files
        testInvalidDotFiles(reader);
    }

    private static void testValidDotFiles(GraphReader<XYNode, Double, TwoDimGraph, String> reader,
                                          GraphWriter<XYNode, Double, TwoDimGraph, String> writer) {
        System.out.println("\n--- Testing Valid DOT Files ---");

        String[] validFiles = {"annoying.dot", "SampleGraph.dot"};

        for (String fileName : validFiles) {
            System.out.println("\nTesting: " + fileName);

            try {
                // Read the test file
                Path filePath = Paths.get(TEST_FILES_PATH, "valid", fileName);
                String content = Files.readString(filePath);

                System.out.println("File content preview:");
                System.out.println(content.substring(0, Math.min(200, content.length())) + "...");

                // Parse the file
                TwoDimGraph graph = reader.read(content);

                System.out.println("[SUCCESS] Successfully parsed!");
                System.out.println("   Nodes: " + graph.getNodes().size());
                System.out.println("   Edges: " + graph.getEdges().size());

                // Test some nodes
                if (!graph.getNodes().isEmpty()) {
                    XYNode firstNode = graph.getNodes().iterator().next();
                    System.out.println("   First node: " + firstNode);
                }

                // Test round-trip (read -> write -> read)
                String generatedDot = writer.write(graph);
                System.out.println("Generated DOT preview:");
                System.out.println(generatedDot.substring(0, Math.min(200, generatedDot.length())) + "...");

                // Try to parse the generated content
                TwoDimGraph roundTripGraph = reader.read(generatedDot);
                System.out.println("[SUCCESS] Round-trip test passed!");
                System.out.println("   Round-trip nodes: " + roundTripGraph.getNodes().size());
                System.out.println("   Round-trip edges: " + roundTripGraph.getEdges().size());

            } catch (IOException e) {
                System.out.println("[ERROR] Failed to read file: " + e.getMessage());
            } catch (ParseException e) {
                System.out.println("[ERROR] Parse error: " + e.getMessage());
                e.printStackTrace();
            } catch (Exception e) {
                System.out.println("[ERROR] Unexpected error: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private static void testInvalidDotFiles(GraphReader<XYNode, Double, TwoDimGraph, String> reader) {
        System.out.println("\n--- Testing Invalid DOT Files (Should Fail) ---");

        String[] invalidFiles = {"invalid.dot"};

        for (String fileName : invalidFiles) {
            System.out.println("\nTesting: " + fileName);

            try {
                // Read the test file
                Path filePath = Paths.get(TEST_FILES_PATH, "invalid", fileName);
                String content = Files.readString(filePath);

                System.out.println("File content:");
                System.out.println(content);

                // Try to parse (should fail)
                TwoDimGraph graph = reader.read(content);

                System.out.println("[ERROR] Invalid file was parsed successfully! This should have failed.");
                System.out.println("   Nodes: " + graph.getNodes().size());
                System.out.println("   Edges: " + graph.getEdges().size());

            } catch (IOException e) {
                System.out.println("[ERROR] Failed to read file: " + e.getMessage());
            } catch (ParseException e) {
                System.out.println("[SUCCESS] Correctly failed with ParseException: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("[WARNING] Failed with unexpected error: " + e.getMessage());
            }
        }
    }
}