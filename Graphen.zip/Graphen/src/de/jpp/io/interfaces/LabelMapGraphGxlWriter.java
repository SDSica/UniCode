package de.jpp.io.interfaces;

public class LabelMapGraphGxlWriter {

}
