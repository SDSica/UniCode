package de.jpp.io.interfaces;

import de.jpp.io.interfaces.GraphReader;
import de.jpp.io.interfaces.ParseException;
import de.jpp.model.TwoDimGraph;
import de.jpp.model.XYNode;
import de.jpp.model.interfaces.Edge;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TwoDimDotReader implements GraphReader<XYNode,Double, TwoDimGraph,String>{
    private static final Pattern NODE_Pattern= Pattern.compile(  "\\s*(\\w+)\\s*\\[(.*?)\\]\\s*;?", Pattern.DOTALL);

    private static final Pattern EDGE_Pattern = Pattern.compile(  "\\s*(\\w+)\\s*->\\s*(\\w+)\\s*(?:\\[([^\\]]+)\\])?\\s*;?");

    private static final Pattern ATTRIBUTE_Pattern = Pattern.compile(
            "(\\w+)\\s*=\\s*(?:\"((?:[^\"\\\\]|\\\\.)*)\"|(\\S+?)(?=\\s|$|\\w+\\s*=))"
    );

    @Override
    public TwoDimGraph read(String input) throws ParseException{
        if (input == null || input.trim().isEmpty()){
            throw new ParseException("Input ist null oder leer.");
        }
        if (!input.contains("digraph") && !input.contains("graph")) {
            throw new ParseException("Invalides DOT Format: missing graph declaration");
        }

        int openBraces = 0;
        int closeBraces = 0;
        boolean insideQuotes = false;
        char prevChar = '\0';

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            if (c == '"' && prevChar != '\\') {
                insideQuotes = !insideQuotes;
            } else if (!insideQuotes) {
                if (c == '{') {
                    openBraces++;
                } else if (c == '}') {
                    closeBraces++;
                }
            }
            prevChar = c;
        }
        if (openBraces == 0 || openBraces != closeBraces) {
            throw new ParseException("Invalides DOT Format: unbalanced braces");
        }
        TwoDimGraph graph = new TwoDimGraph();
        Map<String, XYNode> nodeMap = new HashMap<>();

        String processedInput = preprocessDotInput(input);
        String[] lines = processedInput.split("\n");
        boolean insideGraph = false;

        for (int lineNum = 0; lineNum < lines.length; lineNum++) {
            String line = lines[lineNum].trim();

            if (line.isEmpty() || line.startsWith("//") || line.startsWith("#")) {
                continue;
            }

            try {
                if (line.startsWith("digraph") || line.startsWith("graph")) {
                    insideGraph = true;
                    continue;
                }

                if (line.equals("}")) {
                    insideGraph = false;
                    continue;
                }

                if (!insideGraph) {
                    continue;
                }

                parseLine(line, graph, nodeMap);

            } catch (Exception e) {
                throw new ParseException("Error parsing Zeile " + (lineNum + 1) + ": " + line, e);
            }
        }
        return graph;

    }
    private void parseLine(String line, TwoDimGraph graph, Map<String, XYNode> nodeMap) throws ParseException {
        if (parseNode(line, graph, nodeMap)) {
            return;
        }

        if (parseEdge(line, graph, nodeMap)) {
        }
    }
    private boolean parseNode(String line, TwoDimGraph graph, Map<String, XYNode> nodeMap) throws ParseException {
        Matcher matcher = NODE_Pattern.matcher(line);
        if (!matcher.matches()) {
            return false;
        }

        String nodeId = matcher.group(1);
        String attributesStr = matcher.group(2);

        try {
            Map<String, String> attributes = parseAttributes(attributesStr);

            // Debug output
            System.out.println("DEBUG: Node " + nodeId + " attributes: " + attributes);

            String label = attributes.get("label");
            String xStr = attributes.get("x");
            String yStr = attributes.get("y");

            if (xStr == null) {
                throw new ParseException("Node " + nodeId + " missing x coordinate");
            }
            if (yStr == null) {
                throw new ParseException("Node " + nodeId + " missing y coordinate");
            }

            double x, y;
            try {
                x = Double.parseDouble(xStr);
                y = Double.parseDouble(yStr);
            } catch (NumberFormatException e) {
                throw new ParseException("Invalid coordinates for node " + nodeId + ": x=" + xStr + ", y=" + yStr);
            }

            String cleanLabel = label != null ? label : "";

            try {
                XYNode node = new XYNode(cleanLabel, x, y);
                nodeMap.put(nodeId, node);
                graph.addNode(node);
                System.out.println("DEBUG: Successfully created node: " + node);
            } catch (Exception e) {
                System.out.println("DEBUG: Failed to create node with label: '" + cleanLabel + "', x=" + x + ", y=" + y);
                throw new ParseException("Failed to create node " + nodeId + ": " + e.getMessage(), e);
            }

            return true;
        } catch (ParseException e) {
            throw e;
        } catch (Exception e) {
            throw new ParseException("Error parsing node " + nodeId + ": " + e.getMessage(), e);
        }
    }

    private boolean parseEdge(String line, TwoDimGraph graph, Map<String, XYNode> nodeMap) throws ParseException {
        Matcher matcher = EDGE_Pattern.matcher(line);

        if (!matcher.matches()) {
            return false;
        }

        String fromId = matcher.group(1);
        String toId = matcher.group(2);
        String attributesStr = matcher.group(3);

        XYNode fromNode = nodeMap.get(fromId);
        XYNode toNode = nodeMap.get(toId);

        if (fromNode == null) {
            throw new ParseException("Startknoten " + fromId + " ist nicht definiert");
        }
        if (toNode == null) {
            throw new ParseException("Endknoten " + toId + " ist nicht definiert");
        }

        Double weight = null;
        if (attributesStr != null) {
            Map<String, String> attributes = parseAttributes(attributesStr);
            String distStr = attributes.get("dist");

            if (distStr != null) {
                try {
                    weight = Double.parseDouble(distStr);
                } catch (NumberFormatException e) {
                    throw new ParseException("Invalides dist format für edge " + fromId + " -> " + toId, e);
                }
            }
        }

        if (weight == null) {
            throw new ParseException("Edge " + fromId + " -> " + toId + " hat kein dist/weight");
        }

        graph.addEdge(fromNode, toNode, Optional.of(weight));
        return true;
    }

    private Map<String, String> parseAttributes(String attributesStr) throws ParseException {
        Map<String, String> attributes = new HashMap<>();

        if (attributesStr == null || attributesStr.trim().isEmpty()) {
            return attributes;
        }

        int pos = 0;

        while (pos < attributesStr.length()) {

            while (pos < attributesStr.length() &&
                    (Character.isWhitespace(attributesStr.charAt(pos)) ||
                            attributesStr.charAt(pos) == ',')) {
                pos++;
            }

            if (pos >= attributesStr.length()) break;


            int keyStart = pos;
            while (pos < attributesStr.length() &&
                    (Character.isLetterOrDigit(attributesStr.charAt(pos)) ||
                            attributesStr.charAt(pos) == '_')) {
                pos++;
            }

            if (pos == keyStart) {
                pos++;
                continue;
            }

            String key = attributesStr.substring(keyStart, pos);


            while (pos < attributesStr.length() && Character.isWhitespace(attributesStr.charAt(pos))) {
                pos++;
            }

            if (pos >= attributesStr.length() || attributesStr.charAt(pos) != '=') {

                continue;
            }
            pos++;

            while (pos < attributesStr.length() && Character.isWhitespace(attributesStr.charAt(pos))) {
                pos++;
            }

            String value;
            if (pos < attributesStr.length() && attributesStr.charAt(pos) == '"') {

                pos++;
                int valueStart = pos;

                while (pos < attributesStr.length()) {
                    char currentChar = attributesStr.charAt(pos);

                    if (currentChar == '\\' && pos + 1 < attributesStr.length()) {

                        pos += 2;
                        continue;
                    } else if (currentChar == '"') {
                        break;
                    } else {
                        pos++;
                    }
                }

                if (pos >= attributesStr.length()) {
                    throw new ParseException("Unclosed quote in attributes: " + attributesStr);
                }

                value = attributesStr.substring(valueStart, pos);
                pos++;
            } else {

                int valueStart = pos;
                while (pos < attributesStr.length() &&
                        !Character.isWhitespace(attributesStr.charAt(pos)) &&
                        attributesStr.charAt(pos) != ',') {
                    pos++;
                }

                if (pos == valueStart) {

                    continue;
                }

                value = attributesStr.substring(valueStart, pos);
            }

            attributes.put(key, value);
        }

        return attributes;
    }
    private String preprocessDotInput(String input) {
        StringBuilder processed = new StringBuilder();
        boolean insideQuotes = false;
        char prevChar = '\0';

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            if (c == '"' && prevChar != '\\') {
                insideQuotes = !insideQuotes;
            }

            processed.append(c);
            if (!insideQuotes) {
                if (c == '{') {
                    processed.append('\n');
                } else if (c == '}') {
                    processed.insert(processed.length() - 1, '\n');
                } else if (c == ']' && i + 1 < input.length()) {
                    char nextChar = input.charAt(i + 1);
                    if (Character.isWhitespace(nextChar) || nextChar == '\n' || nextChar == '}') {
                        processed.append('\n');
                    }
                }
            }
            prevChar = c;
        }
        return processed.toString();
    }
}



