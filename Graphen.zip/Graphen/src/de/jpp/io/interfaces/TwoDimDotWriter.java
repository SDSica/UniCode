package de.jpp.io.interfaces;

import de.jpp.io.interfaces.GraphWriter;
import de.jpp.model.TwoDimGraph;
import de.jpp.model.XYNode;
import de.jpp.model.interfaces.Edge;

import java.util.*;

public class TwoDimDotWriter implements GraphWriter<XYNode, Double, TwoDimGraph, String> {

    @Override
    public String write(TwoDimGraph graph) {
        if (graph == null) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        Map<XYNode, String> nodeIds = new HashMap<>();

        int idCounter = 1;
        for (XYNode node : graph.getNodes()) {
            nodeIds.put(node, String.valueOf(idCounter++));
        }

        sb.append("digraph {\n");

        for (XYNode node : graph.getNodes()) {
            String nodeId = nodeIds.get(node);
            sb.append("\t").append(nodeId);
            sb.append(" [label=\"").append(node.getLabel()).append("\"");
            sb.append(" x=").append(node.getX());
            sb.append(" y=").append(node.getY());
            sb.append("]\n");
        }

        for (Edge<XYNode, Double> edge : graph.getEdges()) {
            String fromId = nodeIds.get(edge.getStart());
            String toId = nodeIds.get(edge.getDestination());

            sb.append("\t").append(fromId).append(" -> ").append(toId);

            if (edge.getAnnotation().isPresent()) {
                sb.append(" [dist=").append(edge.getAnnotation().get()).append("]");
            }

            sb.append("\n");
        }

        sb.append("}\n");
        return sb.toString();
    }
}
