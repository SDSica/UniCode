package de.jpp.io.interfaces;
import de.jpp.model.TwoDimGraph;
import de.jpp.model.XYNode;
import de.jpp.model.interfaces.Edge;
import org.jdom2.*;
import org.jdom2.input.SAXBuilder;

import java.io.StringReader;
import java.util.*;

public class TwoDimGxlReader implements GraphReader<XYNode,Double,TwoDimGraph,String> {

    @Override
    public TwoDimGraph read(String input)throws ParseException{
        if (input == null||input.trim().isEmpty()){
            throw new ParseException("Input is null or empty");
        }
        try {
            SAXBuilder saxBuild = new SAXBuilder();
            Document document = saxBuild.build(new StringReader(input));

            Element rootElement = document.getRootElement();
            if (!"gxl".equals(rootElement.getName())) {
                throw new ParseException();
            }

            Element graphElement = rootElement.getChild("graph");
            if (graphElement == null) {
                throw new ParseException();
            }

            TwoDimGraph graph = new TwoDimGraph();
            Map<String, XYNode> nodeMap = new HashMap<>();

            List<Element> nodeElements = graphElement.getChildren("node");
            for (Element nodeElement : nodeElements) {
                parseNode(nodeElement, graph, nodeMap);
            }

            List<Element> edgeElements = graphElement.getChildren("edge");
            for (Element edgeElement : edgeElements) {
                parseEdge(edgeElement, graph, nodeMap);
            }
            return graph;

        } catch (JDOMException e) {
            throw new ParseException("Invalides XML Format", e);
        } catch (java.io.IOException e) {
            throw new ParseException("IO error beim Parsen XML", e);
        } catch (Exception e) {
            if (e instanceof ParseException) {
                throw e;
            }
            throw new ParseException("Error parsing GXL: " + e.getMessage(), e);
        }
    }
    private void parseNode(Element nodeElement, TwoDimGraph graph, Map<String, XYNode> nodeMap) throws ParseException {
        String nodeId = readNodeId(nodeElement);
        if (nodeId == null || nodeId.isEmpty()) {
            throw new ParseException();
        }

        Map<String, String> attributes = parseNodeAttributes(nodeElement);

        String label = attributes.get("description");
        String xStr = attributes.get("x");
        String yStr = attributes.get("y");

       if (xStr == null) {
            throw new ParseException("Node " + nodeId + " missing x coordinate");
        }
        if (yStr == null) {
            throw new ParseException("Node " + nodeId + " missing y coordinate");
        }

        double x, y;
        try {
            x = Double.parseDouble(xStr);
            y = Double.parseDouble(yStr);
        } catch (NumberFormatException e) {
            throw new ParseException("Invalide Koordinate für Knoten " + nodeId);
        }

        XYNode node = new XYNode(label != null ? label : "", x, y);
        nodeMap.put(nodeId, node);
        graph.addNode(node);
    }

    private void parseEdge(Element edgeElement, TwoDimGraph graph, Map<String, XYNode> nodeMap) throws ParseException {
        String fromId = edgeElement.getAttributeValue("from");
        String toId = edgeElement.getAttributeValue("to");

        if (fromId == null || fromId.isEmpty()) {
            throw new ParseException();
        }
        if (toId == null || toId.isEmpty()) {
            throw new ParseException();
        }

        XYNode fromNode = nodeMap.get(fromId);
        XYNode toNode = nodeMap.get(toId);

        if (fromNode == null) {
            throw new ParseException("Kante referenziert unbekannten Knoten: " + fromId);
        }
        if (toNode == null) {
            throw new ParseException("Kante referenziert unbekannten Knoten: " + toId);
        }

        Double weight = parseEdgeWeight(edgeElement);
        if (weight == null) {
            throw new ParseException("Kante von " + fromId + " zu " + toId + " missing cost");
        }

        graph.addEdge(fromNode, toNode, Optional.of(weight));
    }
    private String readNodeId(Element nodeElement) {
        return nodeElement.getAttributeValue("id");
    }

    private Map<String, String> parseNodeAttributes(Element nodeElement) throws ParseException {
        Map<String, String> attributes = new HashMap<>();

        List<Element> attrElements = nodeElement.getChildren("attr");
        for (Element attrElement : attrElements) {
            String attrName = attrElement.getAttributeValue("name");
            if (attrName == null) {
                continue;
            }

            String value = getAttrValue(attrElement);
            if (value != null) {
                attributes.put(attrName, value);
            }
        }
        return attributes;
    }

    private Double parseEdgeWeight(Element edgeElement) throws ParseException {
        List<Element> attrElements = edgeElement.getChildren("attr");
        for (Element attrElement : attrElements) {
            String attrName = attrElement.getAttributeValue("name");
            if ("cost".equals(attrName)) {
                String value = getAttrValue(attrElement);
                if (value != null) {
                    try {
                        return Double.parseDouble(value);
                    } catch (NumberFormatException e) {
                        throw new ParseException("Invalid cost value: " + value);
                    }
                }
            }
        }
        return null;
    }
    private String getAttrValue(Element attrElement) throws ParseException {
        List<Element> children = attrElement.getChildren();
        if (children.isEmpty()) {
            throw new ParseException("Attribute Element hat keine Kinder");
        }

        Element valueElement = children.get(0);
        return valueElement.getTextTrim();
    }
    }


