package de.jpp.io.interfaces;
import com.sun.javafx.scene.control.behavior.TwoLevelFocusPopupBehavior;
import de.jpp.model.TwoDimGraph;
import de.jpp.model.XYNode;
import de.jpp.model.interfaces.Edge;
import org.jdom2.*;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;
import java.util.*;
public class TwoDimGxlWriter implements GraphWriter<XYNode,Double, TwoDimGraph,String> {
    @Override
    public String write(TwoDimGraph graph) {
        if (graph == null) {
            return "";
        }

        try {
            Element rootElement = new Element("gxl");
            Document document = new Document(rootElement);

            Element graphElement = new Element("graph");
            graphElement.setAttribute("id", "id1");
            rootElement.addContent(graphElement);

            Map<XYNode, String> nodeIdMap = new HashMap<>();
            int nodeIdCounter = 1;

            for (XYNode node : graph.getNodes()) {
                nodeIdMap.put(node, "id" + nodeIdCounter++);
            }

            for (XYNode node : graph.getNodes()) {
                Element nodeElement = writeNode(node, nodeIdMap.get(node));
                graphElement.addContent(nodeElement);
            }

            int edgeIdCounter = nodeIdCounter;
            for (Edge<XYNode, Double> edge : graph.getEdges()) {
                String edgeId = "id" + edgeIdCounter++;
                Element edgeElement = writeEdge(edge, nodeIdMap, edgeId);
                graphElement.addContent(edgeElement);
            }

            XMLOutputter xmlOutputter = new XMLOutputter(Format.getPrettyFormat());
            return xmlOutputter.outputString(document);

        } catch (Exception e) {
            return "";
        }
    }

    private Element writeNode(XYNode node, String nodeId) {
        Element nodeElement = new Element("node");
        nodeElement.setAttribute("id", nodeId);

        if (node.getLabel() != null && !node.getLabel().isEmpty()) {
            Element descriptionAttr = createAttribute("description", "string", node.getLabel());
            nodeElement.addContent(descriptionAttr);
        }

        Element xAttr = createAttribute("x", "int", String.valueOf((int) node.getX()));
        nodeElement.addContent(xAttr);

        Element yAttr = createAttribute("y", "int", String.valueOf((int) node.getY()));
        nodeElement.addContent(yAttr);

        return nodeElement;
    }
    private Element writeEdge(Edge<XYNode, Double> edge, Map<XYNode, String> nodeIdMap, String edgeId) {
        Element edgeElement = new Element("edge");

        String fromId = nodeIdMap.get(edge.getStart());
        String toId = nodeIdMap.get(edge.getDestination());

        edgeElement.setAttribute("from", fromId);
        edgeElement.setAttribute("to", toId);
        edgeElement.setAttribute("id", edgeId);

        if (edge.getAnnotation().isPresent()) {
            Double cost = edge.getAnnotation().get();
            Element costAttr = createAttribute("cost", "float", String.valueOf(cost.floatValue()));
            edgeElement.addContent(costAttr);
        }

        return edgeElement;
    }
    private Element createAttribute(String name, String type, String value) {
        Element attrElement = new Element("attr");
        attrElement.setAttribute("name", name);

        Element typeElement = new Element(type);
        typeElement.setText(value);
        attrElement.addContent(typeElement);

        return attrElement;
    }
}

