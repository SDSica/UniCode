package de.jpp.factory;

import de.jpp.algorithm.StartToDestStrategy;
import de.jpp.algorithm.interfaces.SearchStopStrategy;

public class SearchStopFactory {

    public <N> SearchStopStrategy<N> expandAllNodes() {
        return (lastClosedNode) -> false;
    }


    public <N> SearchStopStrategy<N> maxNodeCount(int maxCount) {
        if (maxCount < 0) {
            throw new IllegalArgumentException("Max count cannot be negative");
        }

               return new SearchStopStrategy<N>() {
            private int closedCount = 0;

            @Override
            public boolean stopSearch(N lastClosedNode) {
                closedCount++;
                return closedCount >= maxCount;
            }
        };
    }

    public <N> StartToDestStrategy<N> startToDest(N dest) {
        return new StartToDestStrategy<>(dest);
    }

}
