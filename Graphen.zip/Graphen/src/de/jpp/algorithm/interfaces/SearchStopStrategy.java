package de.jpp.algorithm.interfaces;

public interface SearchStopStrategy<N> {

    boolean stopSearch(N lastClosedNode);


}


