package de.jpp.algorithm.interfaces;

public enum NodeStatus {

    UNKNOWN, OPEN, CLOSED;

}
