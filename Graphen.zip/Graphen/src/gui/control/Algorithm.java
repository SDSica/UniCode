package gui.control;

public enum Algorithm {

    DEPTH, BREADTH, DIJKSTRA, ASTAR;
}
