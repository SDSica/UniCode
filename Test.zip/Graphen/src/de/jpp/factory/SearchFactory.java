package de.jpp.factory;

import de.jpp.algorithm.AStarSearch;
import de.jpp.algorithm.DepthFirstSearch;
import de.jpp.algorithm.BreadthFirstSearch;
import de.jpp.algorithm.DijkstraSearch;
import de.jpp.algorithm.interfaces.EstimationFunction;
import de.jpp.algorithm.interfaces.ObservableSearchResult;
import de.jpp.algorithm.interfaces.SearchAlgorithm;
import de.jpp.algorithm.interfaces.SearchResultImpl;
import de.jpp.model.interfaces.Graph;
import de.jpp.model.interfaces.WeightedGraph;

public class SearchFactory<N, A> {

    public ObservableSearchResult<N,A> getSearchResult(){
        return new SearchResultImpl<>();
    }

    public <G extends Graph<N, A>> SearchAlgorithm<N, A, G> getDepthFirstSearch(G graph, N start) {
        return new DepthFirstSearch<>(graph,start);

    }
    public <G extends Graph<N, A>> SearchAlgorithm<N, A, G> getBreadthFirstSearch(G graph, N start) {

        return new BreadthFirstSearch<>(graph,start);
    }

    public <G extends WeightedGraph<N, A>> SearchAlgorithm<N, A, G> getDijkstra(G graph, N start) {
        return new DijkstraSearch<>(graph,start);
    }

    public static <N, A, G extends WeightedGraph<N, A>> SearchAlgorithm<N, A, G> getAStar(
            G graph, N start, N dest, EstimationFunction<N> estToDest) {
        return new AStarSearch<>(graph, start, dest, estToDest);
    }

}
