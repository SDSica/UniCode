package de.jpp.algorithm;

import de.jpp.factory.GraphFactory;
import de.jpp.model.interfaces.Edge;
import de.jpp.model.interfaces.Graph;

import java.util.*;
import java.util.stream.Collectors;

public class EulerCycle<N, A, G extends Graph<N, A>> {


    public static <N, A, G extends Graph<N, A>> boolean isEulerian(G graph) {
        if (graph == null) {
            return false;
        }

        Collection<N> nodes = graph.getNodes();
        Collection<Edge<N, A>> edges = graph.getEdges();

        if (nodes == null || nodes.isEmpty()) {
            return true;
        }

        if (edges == null) {
            edges = Collections.emptyList();
        }

        Map<N, Integer> inDegree = new HashMap<>();
        Map<N, Integer> outDegree = new HashMap<>();

        for (N node : nodes) {
            inDegree.put(node, 0);
            outDegree.put(node, 0);
        }

        for (Edge<N, A> edge : edges) {
            N start = edge.getStart();
            N dest = edge.getDestination();

            if (outDegree.containsKey(start)) {
                outDegree.put(start, outDegree.get(start) + 1);
            }

            if (inDegree.containsKey(dest)) {
                inDegree.put(dest, inDegree.get(dest) + 1);
            }
        }
        for (N node : nodes) {
            if (!Objects.equals(inDegree.get(node), outDegree.get(node))) {
                return false;
            }
        }
        return true;
    }

    public Optional<Collection<Edge<N, A>>> getCycle(G graph, N startNode) {
        if(graph == null || startNode == null){
            return Optional.empty();
        }
        if (graph.getNodes().isEmpty()) {
            return Optional.empty();
        }
        if (!isEulerian(graph)) {
            return Optional.empty();
        }
        if (!graph.getNodes().contains(startNode)) {
            return Optional.empty();
        }
        Set<Edge<N, A>> unusedEdges = new HashSet<>(graph.getEdges());
        if (unusedEdges.isEmpty()) {
            return Optional.of(new ArrayList<>());
        }
        Map<N, List<Edge<N, A>>> adjacencyList = buildAdjacencyList(unusedEdges);

        List<Edge<N, A>> initialCycle = findCycle(startNode, adjacencyList, unusedEdges);

        if (initialCycle.isEmpty()) {
            return Optional.empty();
        }
        while (!unusedEdges.isEmpty()) {
            N nodeWithUnusedEdges = findNodeWithUnusedEdges(initialCycle, adjacencyList);

            if (nodeWithUnusedEdges == null) {
                break;
            }
            List<Edge<N, A>> newCycle = findCycle(nodeWithUnusedEdges, adjacencyList, unusedEdges);

            if (newCycle.isEmpty()) {
                break;
            }
            initialCycle = insertCycleAtNode(initialCycle, newCycle, nodeWithUnusedEdges);
        }


        return Optional.of(Collections.unmodifiableList(initialCycle));
    }

    private static <N,A> Map<N,List<Edge<N,A>>> buildAdjacencyList(Set<Edge<N,A>>edges){
        Map<N, List<Edge<N, A>>> adjacencyList = new HashMap<>();

        for (Edge<N, A> edge : edges) {
            N start = edge.getStart();
            adjacencyList.computeIfAbsent(start, k -> new ArrayList<>()).add(edge);
        }

        return adjacencyList;
    }
    private static <N, A> List<Edge<N, A>> findCycle(N startNode,
                                                     Map<N, List<Edge<N, A>>> adjacencyList,
                                                     Set<Edge<N, A>> unusedEdges) {
        List<Edge<N, A>> cycle = new ArrayList<>();
        N currentNode = startNode;

        do {
            List<Edge<N, A>> availableEdges = adjacencyList.get(currentNode);

            if (availableEdges == null || availableEdges.isEmpty()) {
                break;
            }

            Edge<N, A> edge = availableEdges.get(0);

            cycle.add(edge);

            availableEdges.remove(edge);
            unusedEdges.remove(edge);

            currentNode = edge.getDestination();

        } while (!currentNode.equals(startNode));

        if (!currentNode.equals(startNode) && !cycle.isEmpty()) {
            return new ArrayList<>();
        }
        return cycle;
    }
    private static <N, A> N findNodeWithUnusedEdges(List<Edge<N, A>> currentCycle,
                                                    Map<N, List<Edge<N, A>>> adjacencyList) {
        Set<N> nodesInCycle = new HashSet<>();
        for (Edge<N, A> edge : currentCycle) {
            nodesInCycle.add(edge.getStart());
            nodesInCycle.add(edge.getDestination());
        }

        for (N node : nodesInCycle) {
            List<Edge<N, A>> availableEdges = adjacencyList.get(node);
            if (availableEdges != null && !availableEdges.isEmpty()) {
                return node;
            }
        }
        return null;
    }
    private static <N, A> List<Edge<N, A>> insertCycleAtNode(List<Edge<N, A>> originalCycle,
                                                             List<Edge<N, A>> newCycle,
                                                             N insertionNode) {
        List<Edge<N, A>> mergedCycle = new ArrayList<>();
        for (int i = 0; i < originalCycle.size(); i++) {
            Edge<N, A> edge = originalCycle.get(i);
            mergedCycle.add(edge);
            if (edge.getDestination().equals(insertionNode)) {
                mergedCycle.addAll(newCycle);
            }
        }
        return mergedCycle;
    }
}
