package de.jpp.algorithm.interfaces;

import de.jpp.algorithm.interfaces.SearchStopStrategy;

public interface SearchStopStrategy<N> {

    boolean stopSearch(N lastClosedNode);


}


