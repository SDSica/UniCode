package de.jpp.algorithm.interfaces;


import de.jpp.algorithm.NodeInformation;
import de.jpp.algorithm.interfaces.NodeStatus;
import de.jpp.algorithm.interfaces.ObservableSearchResult;
import de.jpp.algorithm.interfaces.SearchResult;
import de.jpp.model.interfaces.Edge;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;


public class SearchResultImpl<N, A> implements ObservableSearchResult<N, A> {


    private final Map<N, NodeStatus> nodeStatusMap;
    private final Map<N, NodeInformation<N, A>> nodeInfoMap;
    private final Map<N, Double> startNodeDistances; // Special handling for start nodes


    private final Set<BiConsumer<N, SearchResult<N, A>>> nodeOpenedListeners;
    private final Set<BiConsumer<N, SearchResult<N, A>>> nodeClosedListeners;

    public SearchResultImpl() {
        this.nodeStatusMap = new ConcurrentHashMap<>();
        this.nodeInfoMap = new ConcurrentHashMap<>();
        this.startNodeDistances = new ConcurrentHashMap<>();
        this.nodeOpenedListeners = ConcurrentHashMap.newKeySet();
        this.nodeClosedListeners = ConcurrentHashMap.newKeySet();
    }



    @Override
    public NodeStatus getNodeStatus(N node) {
        if (node == null) {
            return null;
        }
        return nodeStatusMap.getOrDefault(node, NodeStatus.UNKNOWN);
    }

    @Override
    public Optional<Edge<N, A>> getPredecessor(N node) {
        if (node == null) {
            return Optional.empty();
        }

        if (startNodeDistances.containsKey(node)) {
            return Optional.empty();
        }

        return nodeInfoMap.containsKey(node)
                ? Optional.ofNullable(nodeInfoMap.get(node).predecessor())
                : Optional.empty();
    }

    @Override
    public Optional<NodeInformation<N, A>> getInformation(N node) {
        if (node == null) {
            return Optional.empty();
        }


        if (startNodeDistances.containsKey(node)) {

            return Optional.empty();
        }

        return Optional.ofNullable(nodeInfoMap.get(node));
    }

    @Override
    public Collection<N> getAllKnownNodes() {
        return nodeStatusMap.entrySet().stream()
                .filter(entry -> entry.getValue() != NodeStatus.UNKNOWN)
                .map(Map.Entry::getKey)
                .collect(Collectors.toUnmodifiableSet());
    }

    @Override
    public Collection<N> getAllOpenNodes() {
        return nodeStatusMap.entrySet().stream()
                .filter(entry -> entry.getValue() == NodeStatus.OPEN)
                .map(Map.Entry::getKey)
                .collect(Collectors.toUnmodifiableSet());
    }

    @Override
    public void setClosed(N node) {
        if (node == null) {
            return;
        }

        NodeStatus oldStatus = getNodeStatus(node);
        nodeStatusMap.put(node, NodeStatus.CLOSED);


        if (oldStatus != NodeStatus.CLOSED) { //Maybe CLOSED?
            notifyNodeClosed(node);
        }
    }

    @Override
    public void setOpen(N node) {
        if (node == null) {
            return;
        }

        NodeStatus oldStatus = getNodeStatus(node);
        nodeStatusMap.put(node, NodeStatus.OPEN);


        if (oldStatus != NodeStatus.OPEN) { //Unknown?
            notifyNodeOpened(node);
        }
    }

    @Override
    public void setUnknown(N node) {
        if (node == null) {
            return;
        }

        nodeStatusMap.put(node, NodeStatus.UNKNOWN);
        nodeInfoMap.remove(node);
        startNodeDistances.remove(node);
    }

    @Override
    public void setPredecessor(N node, Edge<N, A> predecessor, double distance) {
        if (node == null) {
            return;
        }

        NodeStatus status = getNodeStatus(node);
        if (status == NodeStatus.UNKNOWN) {
            throw new IllegalStateException("Cannot set predecessor for unknown node: " + node);
        }
        if (status == NodeStatus.CLOSED) {
            throw new IllegalStateException("Cannot set predecessor for closed node: " + node);
        }

        if (predecessor == null) {
            startNodeDistances.put(node, distance);
            nodeInfoMap.remove(node);
        } else {
            NodeInformation<N, A> info = new NodeInformation<>(predecessor, distance);
            nodeInfoMap.put(node, info);
            startNodeDistances.remove(node);
        }
    }
    @Override
    public void setPredecessor(N node, NodeInformation<N, A> information) {
        if (information == null) {
            throw new IllegalArgumentException("NodeInformation cannot be null");
        }
        setPredecessor(node, information.predecessor(), information.distance());
    }

    @Override
    public void clear() {
        nodeStatusMap.clear();
        nodeInfoMap.clear();
        startNodeDistances.clear();

    }

    @Override
    public Optional<List<Edge<N, A>>> getPathTo(N dest) {
        if (dest == null || getNodeStatus(dest) == NodeStatus.UNKNOWN) {
            return Optional.empty();
        }

        if(getNodeStatus(dest)==NodeStatus.UNKNOWN){
            return Optional.empty();
        }

        if(startNodeDistances.containsKey(dest)){
            return Optional.of(new ArrayList<>());
        }

        /*if (getNodeStatus(dest) != NodeStatus.CLOSED) {
            return Optional.empty();
        }*/

        List<Edge<N, A>> path = new ArrayList<>();
        N current = dest;

        while (current != null && !startNodeDistances.containsKey(current)) {
            NodeInformation<N, A> info = nodeInfoMap.get(current);
            if (info == null || info.predecessor() == null) {
                break;
            }

            path.add(0, info.predecessor());
            current = info.predecessor().getStart();
        }

        return Optional.of(Collections.unmodifiableList(path));
        /*
        try {

            while (true) {

                if (startNodeDistances.containsKey(current) ||
                        (nodeInfoMap.containsKey(current) && nodeInfoMap.get(current).predecessor() == null)) {
                    break;
                }


                if (!nodeInfoMap.containsKey(current)) {

                    return Optional.empty();
                }

                NodeInformation<N, A> info = nodeInfoMap.get(current);
                Edge<N, A> predecessorEdge = info.predecessor();

                if (predecessorEdge == null) {

                    return Optional.empty();
                }

                path.add(0, predecessorEdge);
                current = predecessorEdge.getStart();


                if (path.size() > nodeStatusMap.size()) {

                    return Optional.empty();
                }
            }

            return Optional.of(Collections.unmodifiableList(path));

        } catch (Exception e) {

            return Optional.empty();
        }

         */
    }



    @Override
    public void addNodeOpenedListener(BiConsumer<N, SearchResult<N, A>> onOpen) {
        if (onOpen != null) {
            nodeOpenedListeners.add(onOpen);
        }
    }

    @Override
    public void removeNodeOpenedListener(BiConsumer<N, SearchResult<N, A>> onOpen) {
        nodeOpenedListeners.remove(onOpen);
    }

    @Override
    public void addNodeClosedListener(BiConsumer<N, SearchResult<N, A>> onClose) {
        if (onClose != null) {
            nodeClosedListeners.add(onClose);
        }
    }

    @Override
    public void removeNodeClosedListener(BiConsumer<N, SearchResult<N, A>> onClose) {
        nodeClosedListeners.remove(onClose);
    }


    public double getDistanceToNode(N node) {
        if (startNodeDistances.containsKey(node)) {
            return startNodeDistances.get(node);
        }

        return nodeInfoMap.containsKey(node)
                ? nodeInfoMap.get(node).distance()
                : Double.POSITIVE_INFINITY;
    }


    private void notifyNodeOpened(N node) {

        if (node == null) {
            return;
        }
        for (BiConsumer<N, SearchResult<N, A>> listener : nodeOpenedListeners) {
            try {
                listener.accept(node, this);
            } catch (Exception e) {

                System.err.println("Error in node opened listener: " + e.getMessage());
            }
        }
    }

    private void notifyNodeClosed(N node) {
        if (node == null) {
            return;
        }
        for (BiConsumer<N, SearchResult<N, A>> listener : nodeClosedListeners) {
            try {
                listener.accept(node, this);
            } catch (Exception e) {

                System.err.println("Error in node closed listener: " + e.getMessage());
            }
        }
    }
}