package de.jpp.algorithm;

import de.jpp.algorithm.interfaces.SearchStopStrategy;


public class StartToDestStrategy<N> implements SearchStopStrategy<N> {

    private final N destination;

    public StartToDestStrategy(N dest) {
        if (dest == null) {
            throw new IllegalArgumentException("Destination cannot be null");
        }
        this.destination = dest;
    }

    @Override
    public boolean stopSearch(N lastClosedNode) {
        return destination.equals(lastClosedNode);
    }

    public N getDest() {
        return destination;
    }

}
