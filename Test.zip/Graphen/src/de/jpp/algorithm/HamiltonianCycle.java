package de.jpp.algorithm;

import de.jpp.model.interfaces.Edge;
import de.jpp.model.interfaces.Graph;

import java.util.*;

public class HamiltonianCycle<N, A, G extends Graph<N, A>> {

    public boolean isHamiltonian(G graph) {
        if (graph == null) {
            return false;
        }

        Collection<N> nodes = graph.getNodes();
        if (nodes.isEmpty()) {
            return true;
        }

        int nodeCount = nodes.size();

        Map<N, Integer> inDegree = new HashMap<>();
        Map<N, Integer> outDegree = new HashMap<>();

        for (N node : nodes) {
            inDegree.put(node, 0);
            outDegree.put(node, 0);
        }

        for (Edge<N, A> edge : graph.getEdges()) {
            N start = edge.getStart();
            N dest = edge.getDestination();

            outDegree.put(start, outDegree.getOrDefault(start, 0) + 1);
            inDegree.put(dest, inDegree.getOrDefault(dest, 0) + 1);
        }

        for (N node : nodes) {
            int totalDegree = inDegree.getOrDefault(node, 0) + outDegree.getOrDefault(node, 0);
            if (totalDegree < nodeCount) {
                return false;
            }
        }

        return true;
    }
    public <T> Set<List<T>> generatePermutations(List<T> input) {
        if (input == null) {
            return new HashSet<>();
        }

        Set<List<T>> result = new HashSet<>();
        List<T> workingList = new ArrayList<>(input);

        if (input.isEmpty()) {
            result.add(new ArrayList<>());
            return result;
        }

        heapPermute(input.size(), workingList, result);
        return result;
    }
    public static <T> void heapPermute(int n, List<T> arr, Set<List<T>> result) {
        // Step 1: If n == 1, add arr to result
        if (n == 1) {
            result.add(new ArrayList<>(arr));
            return;
        }

        heapPermute(n - 1, arr, result);

        for (int i = 0; i <= n - 2; i++) {
            if (n % 2 == 0) {
                Collections.swap(arr, i, n - 1);
            }
            else {
                Collections.swap(arr, 0, n - 1);
            }

            heapPermute(n - 1, arr, result);
        }
    }

    public Optional<Collection<Edge<N, A>>> getCycle(G graph) {
        if (graph == null) {
            return Optional.empty();
        }

        Collection<N> nodes = graph.getNodes();
        if (nodes.isEmpty()) {
            return Optional.of(new ArrayList<>());
        }

        if (nodes.size() == 1) {
            N singleNode = nodes.iterator().next();
            for (Edge<N, A> edge : graph.getNeighbours(singleNode)) {
                if (edge.getDestination().equals(singleNode)) {
                    return Optional.of(Collections.singletonList(edge));
                }
            }
            return Optional.empty();
        }

        List<N> nodeList = new ArrayList<>(nodes);

        Set<List<N>> permutations = generatePermutations(nodeList);

        for (List<N> permutation : permutations) {
            Optional<Collection<Edge<N, A>>> cycle = checkPermutationForCycle(graph, permutation);
            if (cycle.isPresent()) {
                return cycle;
            }
        }

        return Optional.empty();
    }

    private Optional<Collection<Edge<N, A>>> checkPermutationForCycle(G graph, List<N> permutation) {
        if (permutation.isEmpty()) {
            return Optional.of(new ArrayList<>());
        }

        List<Edge<N, A>> cycleEdges = new ArrayList<>();

        for (int i = 0; i < permutation.size(); i++) {
            N currentNode = permutation.get(i);
            N nextNode = permutation.get((i + 1) % permutation.size());

            Edge<N, A> edge = findEdge(graph, currentNode, nextNode);
            if (edge == null) {
                return Optional.empty();
            }

            cycleEdges.add(edge);
        }

        return Optional.of(Collections.unmodifiableList(cycleEdges));
    }

    //helper
    private Edge<N, A> findEdge(G graph, N from, N to) {
        for (Edge<N, A> edge : graph.getNeighbours(from)) {
            if (edge.getDestination().equals(to)) {
                return edge;
            }
        }
        return null;
    }
}