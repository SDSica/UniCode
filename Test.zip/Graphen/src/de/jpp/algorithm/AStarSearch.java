package de.jpp.algorithm;

import de.jpp.algorithm.interfaces.*;
import de.jpp.factory.SearchStopFactory;
import de.jpp.model.interfaces.Edge;
import de.jpp.model.interfaces.WeightedGraph;

import java.util.*;

public class AStarSearch <N,A,G extends WeightedGraph<N,A>>implements SearchAlgorithm<N,A,G>{
    private final G graph;
    private final N startNode;
    private final N destinationNode;
    private final EstimationFunction<N> heuristicFunction;
    private final ObservableSearchResult<N, A> searchResult;
    private volatile boolean stopped = false;
    public AStarSearch(G graph, N start, N destination, EstimationFunction<N> estimationFunction) {
        if (graph == null) {
            throw new IllegalArgumentException("Graph cannot be null");
        }
        if (start == null) {
            throw new IllegalArgumentException("Start node cannot be null");
        }
        if (destination == null) {
            throw new IllegalArgumentException("Destination node cannot be null");
        }
        if (estimationFunction == null) {
            throw new IllegalArgumentException("Estimation function cannot be null");
        }
        this.graph = graph;
        this.startNode = start;
        this.destinationNode = destination;
        this.heuristicFunction = estimationFunction;
        this.searchResult = new SearchResultImpl<>();
    }
    @Override
    public SearchResult<N, A> findPaths(SearchStopStrategy<N> stopStrategy) {
        if (stopStrategy == null) {
            throw new IllegalArgumentException("Stop strategy cannot be null");
        }
        searchResult.clear();
        stopped = false;

        if (!graph.getNodes().contains(startNode)) {
            return searchResult;
        }

       PriorityQueue<AStarNode<N>> openSet = new PriorityQueue<>(
                Comparator.comparingDouble(AStarNode::getFScore)
        );

        Map<N, Double> gScore = new HashMap<>();  // Cost from start to node
        Map<N, Double> fScore = new HashMap<>();  // gScore + heuristic estimate

        double startHeuristic = heuristicFunction.getEstimatedDistance(startNode, destinationNode);
        gScore.put(startNode, 0.0);
        fScore.put(startNode, startHeuristic);

        searchResult.setOpen(startNode);
        searchResult.setPredecessor(startNode, null, 0.0);
        openSet.offer(new AStarNode<>(startNode, 0.0, startHeuristic));

        while (!openSet.isEmpty() && !stopped) {
            AStarNode<N> current = openSet.poll();
            N currentNode = current.getNode();

            if (searchResult.getNodeStatus(currentNode) == NodeStatus.CLOSED) {
                continue;
            }

            if (fScore.containsKey(currentNode) && current.getFScore() > fScore.get(currentNode)) {
                continue;
            }

            searchResult.setClosed(currentNode);

            if (stopStrategy.stopSearch(currentNode)) {
                break;
            }

            if (currentNode.equals(destinationNode)) {
                // Found the shortest path to destination
                break;
            }
            try {
                for (Edge<N, A> edge : graph.getNeighbours(currentNode)) {
                    N neighbor = edge.getDestination();

                    if (searchResult.getNodeStatus(neighbor) == NodeStatus.CLOSED) {
                        continue;
                    }

                    double edgeWeight = graph.getDistance(edge);
                    double currentGScore = gScore.get(currentNode);
                    double tentativeGScore = currentGScore + edgeWeight;

                    double neighborGScore = gScore.getOrDefault(neighbor, Double.POSITIVE_INFINITY);

                    if (tentativeGScore < neighborGScore) {
                        gScore.put(neighbor, tentativeGScore);

                        double heuristic = heuristicFunction.getEstimatedDistance(neighbor, destinationNode);
                        double neighborFScore = tentativeGScore + heuristic;
                        fScore.put(neighbor, neighborFScore);

                        if (searchResult.getNodeStatus(neighbor) == NodeStatus.UNKNOWN) {
                            searchResult.setOpen(neighbor);
                        }

                        searchResult.setPredecessor(neighbor, edge, tentativeGScore);

                        openSet.offer(new AStarNode<>(neighbor, tentativeGScore, neighborFScore));
                    }
                }
            } catch (Exception e) {
            }
        }

        return searchResult;
    }
    @Override
    public SearchResult<N, A> findAllPaths() {
        return findPaths(SearchStopFactory.expandAllNodes());
    }

    @Override
    public ObservableSearchResult<N, A> getSearchResult() {
        return searchResult;
    }

    @Override
    public N getStart() {
        return startNode;
    }

    @Override
    public G getGraph() {
        return graph;
    }

    @Override
    public void stop() {
        stopped = true;
        for (N node : searchResult.getAllOpenNodes()) {
            searchResult.setUnknown(node);
        }
    }

    public N getDestination() {
        return destinationNode;
    }

    public EstimationFunction<N> getHeuristicFunction() {
        return heuristicFunction;
    }

    private static class AStarNode<N> {
        private final N node;
        private final double gScore;  // Cost from start
        private final double fScore;  // gScore + heuristic

        public AStarNode(N node, double gScore, double fScore) {
            this.node = node;
            this.gScore = gScore;
            this.fScore = fScore;
        }

        public N getNode() {
            return node;
        }

        public double getGScore() {
            return gScore;
        }

        public double getFScore() {
            return fScore;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            AStarNode<?> that = (AStarNode<?>) obj;
            return Double.compare(that.gScore, gScore) == 0 &&
                    Double.compare(that.fScore, fScore) == 0 &&
                    Objects.equals(node, that.node);
        }
        @Override
        public int hashCode() {
            return Objects.hash(node, gScore, fScore);
        }
    }
}

