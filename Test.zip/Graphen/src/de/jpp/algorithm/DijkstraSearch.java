package de.jpp.algorithm;
import de.jpp.algorithm.interfaces.*;
import de.jpp.factory.SearchStopFactory;
import de.jpp.model.interfaces.Edge;
import de.jpp.model.interfaces.WeightedGraph;

import java.util.*;

public class DijkstraSearch <N,A,G extends WeightedGraph <N,A>> implements SearchAlgorithm <N,A,G>{

    private final G graph;
    private final N startNode;
    private final ObservableSearchResult<N,A>searchResult;
    private volatile boolean stopped = false;

    public DijkstraSearch(G graph, N start){
        if(graph==null){
            throw new IllegalArgumentException();
        }
        if(start==null){
            throw new IllegalArgumentException();
        }
        this.graph=graph;
        this.startNode=start;
        this.searchResult= new SearchResultImpl<>();

    }

    @Override
    public SearchResult<N, A> findPaths(SearchStopStrategy<N> stopStrategy) {


        if (stopStrategy == null) {
            throw new IllegalArgumentException("Stop strategy cannot be null");
        }
        searchResult.clear();
        stopped = false;

        if (!graph.getNodes().contains(startNode)) {
            return searchResult;
        }
        PriorityQueue<NodeDistancePair<N>> priorityQueue = new PriorityQueue<>(
                Comparator.comparingDouble(NodeDistancePair::getDistance)
        );

        Map<N, Double> distances = new HashMap<>();

        searchResult.setOpen(startNode);
        searchResult.setPredecessor(startNode, null, 0.0);
        distances.put(startNode, 0.0);
        priorityQueue.offer(new NodeDistancePair<>(startNode, 0.0));

        searchResult.setOpen(startNode);  // ← Make sure this is called
        searchResult.setPredecessor(startNode, null, 0.0);
        distances.put(startNode, 0.0);
        priorityQueue.offer(new NodeDistancePair<>(startNode, 0.0));

        while (!priorityQueue.isEmpty() && !stopped) {
            NodeDistancePair<N> current = priorityQueue.poll();
            N currentNode = current.getNode();
            double currentDistance = current.getDistance();

            if (searchResult.getNodeStatus(currentNode) == NodeStatus.CLOSED) {
                continue;
            }

            if (distances.containsKey(currentNode) && currentDistance > distances.get(currentNode)) {
                continue;
            }

            searchResult.setClosed(currentNode);

            if (stopStrategy.stopSearch(currentNode)) {
                break;
            }

            for (Edge<N, A> edge : graph.getNeighbours(currentNode)) {
                N neighbor = edge.getDestination();

                if (searchResult.getNodeStatus(neighbor) == NodeStatus.CLOSED) {
                    continue;
                }

                double edgeWeight = graph.getDistance(edge);
                double newDistance = currentDistance + edgeWeight;
                double currentBestDistance = distances.getOrDefault(neighbor, Double.POSITIVE_INFINITY);

                if (newDistance < currentBestDistance) {
                    distances.put(neighbor, newDistance);

                    if (searchResult.getNodeStatus(neighbor) == NodeStatus.UNKNOWN) {
                        searchResult.setOpen(neighbor);
                    }

                    searchResult.setPredecessor(neighbor, edge, newDistance);
                    priorityQueue.offer(new NodeDistancePair<>(neighbor, newDistance));
                }
            }
        }

        return searchResult;

        /*while (!priorityQueue.isEmpty() && !stopped) {
            NodeDistancePair<N> current = priorityQueue.poll();
            N currentNode = current.getNode();
            double currentDistance = current.getDistance();

            if (searchResult.getNodeStatus(currentNode) == NodeStatus.CLOSED) {
                continue;
            }
            if (distances.containsKey(currentNode) && currentDistance > distances.get(currentNode)) {
                continue;
            }

            searchResult.setClosed(currentNode);

            if (stopStrategy.stopSearch(currentNode)) {
                break;
            }

            try {
                for (Edge<N, A> edge : graph.getNeighbours(currentNode)) {
                    N neighbor = edge.getDestination();

                    if (searchResult.getNodeStatus(neighbor) == NodeStatus.CLOSED) {
                        continue;
                    }
                    double edgeWeight = graph.getDistance(edge);
                    double newDistance = currentDistance + edgeWeight;

                    double currentBestDistance = distances.getOrDefault(neighbor, Double.POSITIVE_INFINITY);

                    if (newDistance < currentBestDistance) {
                        distances.put(neighbor, newDistance);
                        if (searchResult.getNodeStatus(neighbor) == NodeStatus.UNKNOWN) {
                            searchResult.setOpen(neighbor);
                        }
                        searchResult.setPredecessor(neighbor, edge, newDistance);
                        priorityQueue.offer(new NodeDistancePair<>(neighbor, newDistance));
                    }
                }
            } catch (Exception e) {
                continue;
            }
        }

        return searchResult; */ //WORKS FOR NOW?


    }

    @Override
    public SearchResult<N, A> findAllPaths() {
        return findPaths(SearchStopFactory.expandAllNodes());
    }

    @Override
    public ObservableSearchResult<N, A> getSearchResult() {
        return searchResult;
    }

    @Override
    public N getStart() {
        return startNode;
    }

    @Override
    public G getGraph() {
        return graph;
    }

    @Override
    public void stop() {
        stopped = true;
        for (N node : searchResult.getAllOpenNodes()) {
            searchResult.setUnknown(node);
        }
    }

    private static class NodeDistancePair<N> {
        private final N node;
        private final double distance;

        public NodeDistancePair(N node, double distance) {
            this.node = node;
            this.distance = distance;
        }
        public N getNode() {
            return node;
        }
        public double getDistance() {
            return distance;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            NodeDistancePair<?> that = (NodeDistancePair<?>) obj;
            return Double.compare(that.distance, distance) == 0 && Objects.equals(node, that.node);
        }
        @Override
        public int hashCode() {
            return Objects.hash(node, distance);
        }
    }
}
