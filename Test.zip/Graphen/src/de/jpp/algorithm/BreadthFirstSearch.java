package de.jpp.algorithm;

import de.jpp.algorithm.interfaces.*;
import de.jpp.factory.SearchStopFactory;
import de.jpp.model.interfaces.Edge;
import de.jpp.model.interfaces.Graph;

import java.util.LinkedList;
import java.util.Queue;
public class BreadthFirstSearch <N,A,G extends Graph<N,A>> implements SearchAlgorithm<N,A,G> {

    private final G graph;
    private final N startNode;
    private final ObservableSearchResult<N, A> searchResult;
    private volatile boolean stopped = false;
    public BreadthFirstSearch(G graph, N start) {
        if (graph == null) {
            throw new IllegalArgumentException("Graph cannot be null");
        }
        if (start == null) {
            throw new IllegalArgumentException("Start node cannot be null");
        }
        if (!graph.getNodes().contains(start)) {
            throw new IllegalArgumentException("Start node must be in the graph");
        }

        this.graph = graph;
        this.startNode = start;
        this.searchResult = new SearchResultImpl<>(); // We'll need to implement this
    }

    @Override
    public SearchResult<N, A> findPaths(SearchStopStrategy<N> stopStrategy) {
        if (stopStrategy == null) {
            throw new IllegalArgumentException("Stop strategy cannot be null");
        }


        searchResult.clear();
        stopped = false;


        Queue<N> queue = new LinkedList<>();


        searchResult.setOpen(startNode);
        searchResult.setPredecessor(startNode, null, 0.0);
        queue.offer(startNode);

        while (!queue.isEmpty() && !stopped) {

            N currentNode = queue.poll();


            if (searchResult.getNodeStatus(currentNode) == NodeStatus.CLOSED) {
                continue;
            }


            searchResult.setClosed(currentNode);


            if (stopStrategy.stopSearch(currentNode)) {
                break;
            }


            for (Edge<N, A> edge : graph.getNeighbours(currentNode)) {
                N neighbor = edge.getDestination();


                if (searchResult.getNodeStatus(neighbor) == NodeStatus.UNKNOWN) {
                    searchResult.setOpen(neighbor);


                    double currentDistance = searchResult.getInformation(currentNode)
                            .map(info -> info.distance())
                            .orElse(0.0);

                    searchResult.setPredecessor(neighbor, edge, currentDistance + 1.0);
                    queue.offer(neighbor);
                }
            }
        }

        return searchResult;
    }

    @Override
    public SearchResult<N, A> findAllPaths() {
        // Use expandAllNodes strategy to find all paths
        return findPaths(SearchStopFactory.expandAllNodes());
    }

    @Override
    public ObservableSearchResult<N, A> getSearchResult() {
        return searchResult;
    }

    @Override
    public N getStart() {
        return startNode;
    }

    @Override
    public G getGraph() {
        return graph;
    }

    @Override
    public void stop() {
        stopped = true;


        for (N node : searchResult.getAllOpenNodes()) {
            searchResult.setUnknown(node);
        }
    }
}
