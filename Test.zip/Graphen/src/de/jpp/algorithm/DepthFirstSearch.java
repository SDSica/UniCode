package de.jpp.algorithm;

import de.jpp.algorithm.interfaces.*;
import de.jpp.factory.SearchStopFactory;
import de.jpp.model.interfaces.Edge;
import de.jpp.model.interfaces.Graph;

import java.util.Stack;
import java.util.*;

public class DepthFirstSearch<N, A, G extends Graph<N, A>> implements SearchAlgorithm<N, A, G> {

    private final G graph;
    private final N startNode;
    private final ObservableSearchResult<N, A> searchResult;
    private volatile boolean stopped = false;

    public DepthFirstSearch(G graph, N start) {
        /*if (graph == null) {
            throw new IllegalArgumentException("Graph cannot be null");
        }
        if (start == null) {
            throw new IllegalArgumentException("Start node cannot be null");
        }
        Collection<N> graphNodes = graph.getNodes();
        if(graphNodes == null){
            throw new IllegalArgumentException("Graph.getNodes() returns null");
        }
        if (!graph.getNodes().contains(start)) {
            StringBuilder errorMsg = new StringBuilder();
            errorMsg.append("Start Node must be in graph");
            errorMsg.append("Start Node ").append(start).append("(").append(start.getClass().getSimpleName()).append(")");
            errorMsg.append("graph contains").append(graphNodes.size()).append("nodes");

            int count = 0;
            for (N node : graphNodes) {
                if (count > 0) errorMsg.append(", ");
                errorMsg.append("'").append(node).append("'");
                if (++count > 10) {errorMsg.append("...");
                    break;
                }
            }
            errorMsg.append("]");

            throw new IllegalArgumentException("Start node must be in the graph");
        }
        */
        if (graph == null) {
            throw new IllegalArgumentException("Graph cannot be null");
        }
        if (start == null) {
            throw new IllegalArgumentException("Start node cannot be null");
        }

        this.graph = graph;
        this.startNode = start;
        this.searchResult = new SearchResultImpl<>();
    }
    @Override
    public SearchResult<N, A> findPaths(SearchStopStrategy<N> stopStrategy) {
        if (stopStrategy == null) {
            throw new IllegalArgumentException("Stop strategy cannot be null");
        }

        searchResult.clear();
        stopped = false;

        if (!graph.getNodes().contains(startNode)) {
           return searchResult;
        }

        Stack<N> stack = new Stack<>();

        searchResult.setOpen(startNode);
        searchResult.setPredecessor(startNode, null, 0.0);
        stack.push(startNode);

        while (!stack.isEmpty() && !stopped) {

            N currentNode = stack.pop();

            if (searchResult.getNodeStatus(currentNode) == NodeStatus.CLOSED) {
                continue;
            }
            searchResult.setClosed(currentNode);

            if (stopStrategy.stopSearch(currentNode)) {
                break;
            }
            try{
                for (Edge<N, A> edge : graph.getNeighbours(currentNode)) {
                    N neighbor = edge.getDestination();


                    if (searchResult.getNodeStatus(neighbor) == NodeStatus.UNKNOWN) {
                        searchResult.setOpen(neighbor);
                        searchResult.setPredecessor(neighbor, edge, 1.0);
                        stack.push(neighbor);
                    }
                }
            } catch (Exception e){
                continue;
            }

        }
        return searchResult;
    }
    @Override
    public SearchResult<N, A> findAllPaths() {

        return findPaths(SearchStopFactory.expandAllNodes());
    }
    @Override
    public ObservableSearchResult<N, A> getSearchResult() {
        return searchResult;
    }

    @Override
    public N getStart() {
        return startNode;
    }

    @Override
    public G getGraph() {
        return graph;
    }

    @Override
    public void stop() {
        stopped = true;
    }
}