package de.jpp.algorithm;

import de.jpp.model.interfaces.Edge;

public record NodeInformation<N, A>(Edge<N, A> predecessor,double distance) {

    public NodeInformation {
        /*if (predecessor == null) {
            throw new IllegalArgumentException();
        }*/
        if (distance < 0) {
            throw new IllegalArgumentException();
        }
}
}
