package de.jpp.io.interfaces;

import de.jpp.model.LabelMapGraph;
import de.jpp.model.interfaces.Edge;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class LabelMapGraphGxlWriter implements GraphWriter<String, Map<String, String>, LabelMapGraph, String> {
    @Override
    public String write(LabelMapGraph graph) {
        if (graph == null) {
            return "";
        }
        try {
            Element rootElement = new Element("gxl");
            Document document = new Document(rootElement);

            Element graphElement = new Element("graph");
            graphElement.setAttribute("id", "id1");
            rootElement.addContent(graphElement);

            Map<String, String> nodeIdMap = new HashMap<>();
            int idCounter = 1;

            for (String node : graph.getNodes()) {
                nodeIdMap.put(node, "id" + idCounter++);
            }

            for (String node : graph.getNodes()) {
                Element nodeElement = writeNode(node, nodeIdMap.get(node));
                graphElement.addContent(nodeElement);
            }

            for (Edge<String, Map<String, String>> edge : graph.getEdges()) {
                String edgeId = "id" + idCounter++;
                Element edgeElement = writeEdge(edge, nodeIdMap, edgeId);
                graphElement.addContent(edgeElement);
            }
            XMLOutputter xmlOutputter = new XMLOutputter(Format.getPrettyFormat());
            return xmlOutputter.outputString(document);

        } catch (Exception e) {
            return "";
        }
    }
    private Element writeNode(String node, String nodeId) {
        Element nodeElement = new Element("node");
        nodeElement.setAttribute("id", nodeId);

        if (node != null && !node.equals(nodeId)) {
            Element attr = createAttribute("description", "string", node);
            nodeElement.addContent(attr);
        }

        return nodeElement;
    }

    private Element writeEdge(Edge<String, Map<String, String>> edge, Map<String, String> nodeIdMap, String edgeId) {
        Element edgeElement = new Element("edge");

        String fromId = nodeIdMap.get(edge.getStart());
        String toId = nodeIdMap.get(edge.getDestination());

        edgeElement.setAttribute("from", fromId);
        edgeElement.setAttribute("to", toId);
        edgeElement.setAttribute("id", edgeId);

        Optional<Map<String, String>> annotation = edge.getAnnotation();
        if (annotation.isPresent()) {
            for (Map.Entry<String, String> entry : annotation.get().entrySet()) {
                Element attr = createAttribute(entry.getKey(), "string", entry.getValue());
                edgeElement.addContent(attr);
            }
        }

        return edgeElement;
    }
    private Element createAttribute(String name, String type, String value) {
        Element attrElement = new Element("attr");
        attrElement.setAttribute("name", name);

        Element typeElement = new Element(type);
        typeElement.setText(value);
        attrElement.addContent(typeElement);
        return attrElement;
    }
}
