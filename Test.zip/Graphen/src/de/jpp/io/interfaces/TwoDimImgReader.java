package de.jpp.io.interfaces;

import de.jpp.factory.GraphFactory;
import de.jpp.model.TwoDimGraph;
import de.jpp.model.XYNode;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class TwoDimImgReader implements GraphReader<XYNode, Double, TwoDimGraph, BufferedImage> {

    @Override
    public TwoDimGraph read(BufferedImage image) throws ParseException {
        if (image == null) {
            throw new ParseException("Input image is null");
        }

        TwoDimGraph graph = GraphFactory.createNewTwoDimGraph();
        int width = image.getWidth();
        int height = image.getHeight();

       Map<String, XYNode> nodeMap = new HashMap<>();


        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (isPath(image, x, y)) {
                    String label = "(" + x + "|" + y + ")";
                    XYNode node = new XYNode(label, x, y);
                    graph.addNode(node);
                    nodeMap.put(getCoordinateKey(x, y), node);
                }
            }
        }


        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (isPath(image, x, y)) {
                    XYNode currentNode = nodeMap.get(getCoordinateKey(x, y));


                    int[][] directions = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};

                    for (int[] dir : directions) {
                        int newX = x + dir[0];
                        int newY = y + dir[1];


                        if (isValidCoordinate(newX, newY, width, height) &&
                                isPath(image, newX, newY)) {

                            XYNode adjacentNode = nodeMap.get(getCoordinateKey(newX, newY));


                            graph.addEdge(currentNode, adjacentNode, Optional.of(1.0));
                        }
                    }
                }
            }
        }

        return graph;
    }

    private boolean isPath(BufferedImage image, int x, int y) {
        int rgb = image.getRGB(x, y);
        Color color = new Color(rgb);


        float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
        float brightness = hsb[2];

        return brightness >= 0.5f;
    }


    private String getCoordinateKey(int x, int y) {
        return x + "," + y;
    }

    private boolean isValidCoordinate(int x, int y, int width, int height) {
        return x >= 0 && x < width && y >= 0 && y < height;
    }
}