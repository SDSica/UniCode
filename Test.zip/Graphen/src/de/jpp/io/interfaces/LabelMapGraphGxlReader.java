package de.jpp.io.interfaces;

import de.jpp.factory.GraphFactory;
import de.jpp.model.LabelMapGraph;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LabelMapGraphGxlReader implements GraphReader<String, Map<String, String>, LabelMapGraph, String> {
    @Override
    public LabelMapGraph read(String input) throws ParseException {
        if (input == null || input.isEmpty()) {
            throw new ParseException();
        }

        LabelMapGraph graph = GraphFactory.createNewLabelMapGraph();
        SAXBuilder saxBuilder = new SAXBuilder();

        try {
            Document document = saxBuilder.build(new StringReader(input));
            Element root = document.getRootElement();

            if (!"gxl".equals(root.getName())) {
                throw new ParseException();
            }

            Element graphElement = root.getChild("graph");
            if (graphElement == null) {
                throw new ParseException();
            }


            Map<String, String> idToNodeMap = new HashMap<>();


            List<Element> nodes = graphElement.getChildren("node");
            for (Element nodeElement : nodes) {
                String nodeId = nodeElement.getAttributeValue("id");
                if (nodeId == null) {
                    throw new ParseException();
                }


                String nodeValue = readNodeValue(nodeElement);

                graph.addNode(nodeValue);
                idToNodeMap.put(nodeId, nodeValue);
            }


            List<Element> edges = graphElement.getChildren("edge");
            for (Element edgeElement : edges) {
                String from = edgeElement.getAttributeValue("from");
                String to = edgeElement.getAttributeValue("to");

                if (from == null || to == null) {
                    throw new ParseException();
                }

                String startNode = idToNodeMap.get(from);
                String destNode = idToNodeMap.get(to);

                if (startNode == null || destNode == null) {
                    throw new ParseException();
                }

                // Read edge attributes
                Map<String, String> attributes = readEdgeAttributes(edgeElement);

                graph.addEdge(startNode, destNode, java.util.Optional.of(attributes));
            }
        } catch (JDOMException | IOException e) {
            throw new ParseException("Error parsing GXL document: " + e.getMessage(), e);
        }
        return graph;
    }


    private String readNodeValue(Element nodeElement) throws ParseException {
        // Look for description attribute first
        List<Element> attrElements = nodeElement.getChildren("attr");
        for (Element attrElement : attrElements) {
            String name = attrElement.getAttributeValue("name");
            if ("description".equals(name)) {
                String value = getAttrValue(attrElement);
                if (value != null && !value.isEmpty()) {
                    return value;
                }
            }
        }

        String nodeId = nodeElement.getAttributeValue("id");
        return nodeId != null ? nodeId : ""; // Return empty string if somehow no ID
    }

    private Map<String, String> readEdgeAttributes(Element edgeElement) throws ParseException {
        Map<String, String> attributes = new HashMap<>();
        List<Element> attrElements = edgeElement.getChildren("attr");

        for (Element attrElement : attrElements) {
            String name = attrElement.getAttributeValue("name");
            if (name == null) {
                continue;
            }

            String value = getAttrValue(attrElement);
            if (value != null) {
                attributes.put(name, value);
            }
        }

        return attributes;
    }

    private String getAttrValue(Element attrElement) throws ParseException {
        String value = attrElement.getChildTextTrim("string");
        if (value != null) {
            return value;
        }

        value = attrElement.getChildTextTrim("float");
        if (value != null) {
            return value;
        }

        value = attrElement.getChildTextTrim("int");
        if (value != null) {
            return value;
        }

        value = attrElement.getChildTextTrim("bool");
        if (value != null) {
            return value;
        }

        if (attrElement.getChildren().isEmpty()) {
            throw new ParseException("Attribute element has no children - violates GXL specification");
        }

        return null;
    }
}